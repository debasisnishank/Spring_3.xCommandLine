

public class Student {
 public String  studentName;
 public Student(){
 System.out.println("I am inside of  default constructor");
 studentName = "Debasis Nishak";
 }
 public String getStudentName() {
	 return studentName;
 }
}
